package com.example.android.solarsystemquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

   // ** global variable to keep track of the score**//

    int score = 0;

    EditText nameField;
    RadioButton mercuryAnswer;
    RadioButton eightMinutesAnswer;
    RadioButton jSunAnswer;
    RadioButton jupiterAnswer;
    RadioButton milkyWayAnswer;
    RadioButton noMoonsAnswer;
    RadioButton giantStormAnswer;
    CheckBox ringsSurrounded;
    CheckBox tiltedOrbit;
    CheckBox oneYear;
    CheckBox alphaCentauri;
    CheckBox hydrogenHelium;
    CheckBox redDwarf;
    EditText plutoAnswer;

    RadioGroup radioGroup1;
    RadioGroup radioGroup2;
    RadioGroup radioGroup3;
    RadioGroup radioGroup4;
    RadioGroup radioGroup5;
    RadioGroup radioGroup6;
    RadioGroup radioGroup7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nameField = findViewById(R.id.name_field);

        //** initialization of right question answers**/

        mercuryAnswer = findViewById(R.id.mercury_button);
        eightMinutesAnswer = findViewById(R.id.eight_minutes_button);
        jSunAnswer = findViewById(R.id.j_sun_button);
        jupiterAnswer = findViewById(R.id.jupiter_button);
        milkyWayAnswer = findViewById(R.id.milky_way_button);
        noMoonsAnswer = findViewById(R.id.no_moons_button);
        giantStormAnswer = findViewById(R.id.giant_storm_button);
        ringsSurrounded = findViewById(R.id.rings_surrounded);
        tiltedOrbit = findViewById(R.id.tilted_orbit);
        oneYear = findViewById(R.id.one_year);
        alphaCentauri = findViewById(R.id.alpha_centauri);
        hydrogenHelium = findViewById(R.id.hydrogen_helium);
        redDwarf = findViewById(R.id.red_dwarf);
        plutoAnswer = findViewById(R.id.pluto_answer);

// ** for reset method**//
        radioGroup1 = findViewById(R.id.first_radio_group);
        radioGroup2 = findViewById(R.id.second_radio_group);
        radioGroup3 = findViewById(R.id.third_radio_group);
        radioGroup4 = findViewById(R.id.fourth_radio_group);
        radioGroup5 = findViewById(R.id.fifth_radio_group);
        radioGroup6 = findViewById(R.id.sixth_radio_group);
        radioGroup7 = findViewById(R.id.seventh_radio_group);

    }

//** calculates the score based on the right answers**//

    public int calculateScore(int score) {


        boolean firstQuestion =
                mercuryAnswer.isChecked();
        if (firstQuestion) score+=1;



        boolean secondQuestion =
                eightMinutesAnswer.isChecked();
        if (secondQuestion) {
            score += 1;
        }

        boolean thirdQuestion =
                jSunAnswer.isChecked();
        if (thirdQuestion) {
            score += 1;
        }
        boolean fourthQuestion =
                jupiterAnswer.isChecked();
        if (fourthQuestion) {
            score += 1;
        }
        boolean fifthQuestion =
                milkyWayAnswer.isChecked();
        if (fifthQuestion) {
            score += 1;
        }
        boolean sixthQuestion =
                noMoonsAnswer.isChecked();
        if (sixthQuestion) {
            score += 1;
        }
        boolean seventhQuestion =
                giantStormAnswer.isChecked();
        if (seventhQuestion) {
            score += 1;
        }
        boolean eightQuestion1 =
                tiltedOrbit.isChecked();
        boolean eightQuestion2 =
                ringsSurrounded.isChecked();
        if (eightQuestion1 && !eightQuestion2) {
            score += 1;
        }
        boolean ninthQuestion1 =
                alphaCentauri.isChecked();
        boolean ninthQuestion2 =
                redDwarf.isChecked();
        if (ninthQuestion1 && !ninthQuestion2) {
            score += 1;
        }

        String tenthQuestion = plutoAnswer.getText().toString();
        if (tenthQuestion.contentEquals("Pluto"));
        score = 1;

        return (score);

    }

    public void submitAnswer(View view) {
        String name = nameField.getText().toString();
        int finalScore = calculateScore(score);
        String finalScoreMessage = name;
        finalScoreMessage += "\n" + finalScore;

        Toast.makeText(this, finalScoreMessage, Toast.LENGTH_LONG).show();
    }

}




